-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2021 at 05:14 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feline_movies`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `pwd`) VALUES
(2, 'Abigail', '$2y$10$DVxw3GE1g1F4pREL8ltHrOlpKr1iz8QgMzm5Z8tyy7cMg5rHp9Lyu'),
(3, 'Anna', 'Ahiadeke11'),
(4, 'Feninig', '$2y$10$C1foQsJ29ynPKjHo/UBfU.QG8zD22DwZzTD3Pk77RdtFxEOa2Jike'),
(5, 'khkkg', '$2y$10$vYQ1D4YKQtzcTxoteoUuV.xdx0m.zqKfZ0eDF1EG.QM35TMKflFp.'),
(6, 'nii', 'HelloWorld.'),
(7, 'nii', '$2y$10$j2KFN76hWr8kkSTQYM82buwQzNLx5pdDVdMVHoe0xCYIy7q1FA3ha'),
(8, 'Nyaniba', '$2y$10$ABZEW0F/FeBE1dHPH8n8VOHHcdZ91KEB1mzPkpQaF9cDyNXzFuvP2'),
(9, 'Nyaniba', '$2y$10$K9DBwZ7u.0/xZdOa9lJmsuw2f.iUc22pshirZ0mjv5PPpcR.HOsLu'),
(10, 'rleaxing', '$2y$10$4ZtT0IvQ/HHrXjef3rtuuu/L1SuZsQm2E86WMaYu/oxzBVRzJmf2.'),
(11, 'salomey', '$2y$10$Lk7kj8BhQf6hzRCNsTyyKOTfZ31J2dl/.AcjNvn8EyaVi2d5vk076'),
(12, 'admin', 'pass'),
(72, 'remah', '$2y$10$Xfj9pScIDWn6Y53KhjwHD.ce8D/zYvc7IqDJEWR81tH7D/t5DqYLC'),
(73, 'nii@gmail.com', '$2y$10$iiKXLoEHrcAosyE8EQsSMegOW1yDIjoyvmxr/FEcCm3M8097GCnTy'),
(74, 'admin', '$2y$10$6QjdcsGLL.4CNka4hX6ObOssjh77PCd6R79ie6h9zjjRZGwTIb3My'),
(75, '', '$2y$10$1p6i733tZh6ipiVYiPXe7OXWh47UT2SZhUC7ydZN1nmRnAPicuhHW');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(255) NOT NULL,
  `category_id` int(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_id`, `category_name`, `post`) VALUES
(1, 1, '                                                            Horror', ''),
(2, 2, 'Action', ''),
(3, 3, 'Thriller', ''),
(4, 4, 'Romance', ''),
(5, 5, 'Comedy', ''),
(6, 6, 'Adventure', ''),
(7, 7, 'Comedy', '');

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE `genre` (
  `id` int(255) NOT NULL,
  `genre_name` varchar(255) NOT NULL,
  `category_id` int(255) NOT NULL,
  `genreid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`id`, `genre_name`, `category_id`, `genreid`) VALUES
(1, 'Bollywood', 1, 1),
(2, 'Nollywood', 2, 2),
(3, 'Hollywood', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `id` int(255) NOT NULL,
  `cat_id` int(255) NOT NULL,
  `genre_id` int(255) NOT NULL,
  `mv_name` varchar(255) NOT NULL,
  `mv_des` varchar(255) NOT NULL,
  `mv_tag` varchar(255) NOT NULL,
  `link1` varchar(255) NOT NULL,
  `link2` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `lang` varchar(255) NOT NULL,
  `director` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `cat_id`, `genre_id`, `mv_name`, `mv_des`, `mv_tag`, `link1`, `link2`, `img`, `date`, `lang`, `director`, `meta_description`) VALUES
(1, 2, 2, 'Fine Wine ', '\r\nA lonely but rich older man genuinely falls in love with a younger woman and finds himself in the crossfire of society and in competition with a younger man for her heart.', 'love', 'N/A', 'N/A', 'fine-wine.jpg', '2021-12-01', 'English', 'Seyi Babatope', 'Adult-Young Love'),
(6, 2, 3, 'black rose', '', 'love', 'N/A', 'N/A', 'finals_black rose.png', '2021-12-05', 'English', ' Okechukwu Oku', 'suspense'),
(8, 1, 1, 'The perfect picture', 'The film is about three women pushing their thirties and making bold attempts to change their lives, but destiny had other plans for them. Now in the sequel, the ladies are back, this time pushing their forties. Even though they are older and wiser, they ', 'love', 'N/A', 'N/A', 'finals_the perfect picture.png', '2021-12-18', 'English', ' Shirley Frimpong-Manso.', 'love'),
(10, 2, 2, 'Mama Drama', 'drama', 'woman', 'N/A', 'N/A', 'finals_finding hubby.png', '2021-12-08', 'English', 'Seyi Babatope', 'betrayals'),
(11, 2, 2, 'Mama Drama', '', 'love', 'N/A', 'N/A', 'finals_mama drama.png', '2021-12-26', 'English', ' Shirley Frimpong-Manso.', 'betrayals');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `genre`
--
ALTER TABLE `genre`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
