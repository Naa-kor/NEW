<?php
include 'header.php';
include 'ft.php';
include 'db.php';
?>

<!--Registration forms-->

<div class="container" style="text-align": center;>
    <div class="head" >
        <h1>Register as an admin</h1>
    </div>
    <form action="registeradmin.php" method="post">
  <div class="form-group">
  <form>

  <div class="mb-3"> 
  <div class="mb-3">
    <label for="exampleInputUsername" class="form-label">Password</label>
    <input type="text"  name="username"class="form-control" id="exampleInputUsername">
  </div>
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password"  name="pwds"class="form-control" id="exampleInputPassword1">
  </div>

  <button type="submit" name="Submit" class="btn btn-primary">Submit</button>
</form>
</div>


<?php
//Adding to database
if(isset($_POST['Submit'])){
    
    $usname = $_POST['username'];
    $email=$_POST['email'];
    $pwd = $_POST['pwds'];
    $hash = password_hash("$pwd", PASSWORD_BCRYPT);

    $query = "INSERT INTO `user` (`username`,`email`,`pwds`) VALUES ('$usname', '$hash')";
    $run = (mysqli_query($con,$query));
    if($run) {
       echo "<script>alert('User successfully registered:..');window.location.href='adminlist.php';</script>" ;
    }
    else{
         echo "something went wrong";
        }
    

}


?>