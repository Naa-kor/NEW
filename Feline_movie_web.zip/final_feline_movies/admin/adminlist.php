<?php
include 'header.php';

include 'db.php';
?>

<!-- table -->
<div class="container">
    <div class="head" style="padding-top:10px; padding-bottom:10px; text-align: center;">
        <h1>Admins of Feline Movies</h1>
        <br>
    </div>
<table class="table table-striped">
  <thead>
    
    <tr>
      <th scope="col">id</th>
      <th scope="col">Username</th>
      <th scope="col">Password</th>
      <th scope="col">CRUD</th>
    </tr>
  </thead>

  <?php
      $query = "SELECT * FROM admin";
      $run = mysqli_query($con, $query) ;
      if($run){
          while ($row = mysqli_fetch_assoc($run)){
?>
  <tbody>
    <tr>
      <th scope="row"><?php echo $row['id'];?></th>
      <td><?php echo $row['uname'];?></td>
      <td><p class="">Password Encrypted</p></td>
      <td><a class="btn btn-danger" href="deleteadmin.php?id=<?php echo $row['id'];?>">Delete</a> &nbsp;<a class="btn btn-success" href="registeradmin.php">New Admin</a></td>
    </tr>
    <?php
}
}

?>

  </tbody>
</table>
</div>
