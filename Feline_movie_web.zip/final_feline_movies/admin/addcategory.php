<?php
Include "header.php";
Include "ft.php";
Include "db.php";
?>

<!-- Category forms-->
<div class= "container">
   <!<div class = "head">
        <div class="jumbotron">
  <h1 class="display-4">Add a category</h1>
  <p class="lead">A a category and please mention the Category ID </p>
  <hr class="my-4">
  <form action="addcategory.php" method="post" >
  <div class="form-row">
    <div class="col-7">
      <input type="text" name="catname" class="form-control" placeholder="Category name">
    </div>
    <div class="col">
      <input type="text" name="catid" class="form-control" placeholder="Category Id">
    </div>
  </div>
  <br></br>
  <button type="submit" name="submit" class="btn btn-primary">Add category</button>
</form>
</div>
    </div>
</div>


<!--PHP ADD TO DATABASE-->
<?php
if(isset($_POST['submit'])){
    $catname = $_POST['catname'];
    $catid= $_POST['catid'];
    $query= "INSERT INTO `category`(`category_id`, `category_name`) VALUES ('$catid', '$catname')";
    $run = (mysqli_query($con,$query));
    if($run) {
       echo "<script>alert('category successfully added:..');window.location.href='categorylist.php';</script>" ;
    }
    else{
         echo "<script>alert ('something went wrong');</script>";
        }

}


?>