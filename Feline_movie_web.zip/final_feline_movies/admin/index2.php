
<?php
include 'db.php';
include 'header.php';
?>

<div class="content">
<div clas="row"> 
    <div class="col-sm-6">
        <div class= "card bg-info" sytle="border:1px solid #ccc;">
            <div class="card-body text-center">
                <h5 class="card-titile">Total Number of Posts</h5>
                <p class="card-text"><?php
            $query="SELECT count(*) as total_movie from movie";
            $run =mysqli_query($con, $query);
            if($run){
                while($row =mysqli_fetch_assoc($run)){
                    echo $row['total_movie'];
                }
            }
            ?></p>

            </div>
        </div>
    </div>
    <!---category-->
    <div class="col-sm-6">
        <div class= "card bg-danger" sytle="border: 1px solid #ccc;">
            <div class="card-body text-center">
                <h5 class="card-titile">Total Number of Categories</h5>
                <p class="card-text"><?php
            $query="SELECT count(*) as total_category from category";
            $run =mysqli_query($con, $query);
            if($run){
                while($row =mysqli_fetch_assoc($run)){
                    echo $row['total_category'];
                }
            }
                ?>
                </p>

            </div>
        </div>
    </div>
    <!---admin-->
    <div class="col-sm-6">
        <div class= "card  bg-secondary" sytle="border:1px solid #ccc;">
            <div class="card-body text-center">
                <h5 class="card-titile">Total Number of Admins</h5>
                <p class="card-text"><?php
            $query="SELECT count(*) as total_admin from admin";
            $run =mysqli_query($con, $query);
            if($run){
                while($row =mysqli_fetch_assoc($run)){
                    echo $row['total_admin'];
                }
            }
                ?>
                </p>

            </div>
        </div>
    </div>

    <!--genre-->
    <div class="col-sm-6">
        <div class= "card bg-primary" sytle="border:1px solid #ccc;">
            <div class="card-body text-center">
                <h5 class="card-titile">Total Number of Genre</h5>
                <p class="card-text"><?php
            $query="SELECT count(*) as total_genre from genre";
            $run =mysqli_query($con, $query);
            if($run){
                while($row =mysqli_fetch_assoc($run)){
                    echo $row['total_genre'];
                }
            }
                ?>
                </p>

            </div>
        </div>
       
    </div>
    <br>
</div>
</div>
