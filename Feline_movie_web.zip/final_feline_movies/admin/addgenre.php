<?php
include 'header.php';
include 'ft.php';
include 'db.php';
?>

<!-- Category forms-->
<div class= "container">
   <!<div class = "head">
        <div class="jumbotron">
  <h1 class="display-4">Add a Genre</h1>
  <p class="lead">A a getprotobyname and please mention the Category ID </p>
  <hr class="my-4">
  <form action="addgenre.php" method="post" >
  <div class="form-row">
    <div class="col-7">
      <input type="text" name="genrename" class="form-control" placeholder="Genre name">
    </div>
    <div class="col">
      <input type="text" name="cat_id" class="form-control" placeholder="Category Id">
    </div>
    <div class="col">
      <input type="text" name="genre_id" class="form-control" placeholder="Genre Id">
    </div>
  </div>
  <br></br>
  <button type="submit" name="submit" class="btn btn-primary">Add Genre</button>
</form>
</div>
    </div>
</div>


<?php
if(isset($_POST['submit'])){
    $gename= $_POST['genrename'];
    $cat_id = $_POST['cat_id'];
    $genre =$_POST['genre_id'];

    $query= "INSERT INTO `genre`( `genre_name`, `category_id`, `genreid`) VALUES ('$gename','$cat_id','$genre')";
    $run= mysqli_query($con, $query);
    if ($run){
        echo "<script>alert('genre successfully added:..');window.location.href='genrelist.php';</script>" ;
    }
    else{
         echo "<script>alert ('something went wrong:(');</script>";
        }
    }
?>
