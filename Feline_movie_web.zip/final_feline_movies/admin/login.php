<Html>
<head>
<style>


</style>
</head>
<body>
<?php
include 'header.php';
include 'ft.php';
include 'db.php';
?>
<head> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> 
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script></head>
<div class="container" style="text-align": center;>
    <div class="head" >
        <h4>Login to continue</h4>
    </div>
    <form action="login.php" method="post">
  <div class="form-group">
  <form>

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="text" name="uname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password"  name="pwd"class="form-control" id="exampleInputPassword1">
  </div>

  <button type="submit" name="submit" class="btn btn-primary">Login</button>
</form>
</div>

<?php

if(isset($_POST["submit"])){
    $user = $_POST["uname"];
    $pwd = $_POST["pwd"];

    $query = "SELECT * FROM `admin` where `uname`= '$user'and `pwd`='$pwd'";
    $run = $con->query($query);
    if ($run->num_rows>0){
      while ($row=$run->fetch_assoc()){
        echo "<script>alert('Logged in succesfully');window.location.href='index.php';</script>";
      }
    }
    else{
        echo "<script>alert('Check your password they do not match');</script>";
    }

 }
?>
<br>
<hr>
<br>
<h5>Or Register as a user</h5>

<hr>


<!--Registration forms-->

<div class="container" style="text-align": center;>
    <div class="head" >
        <h4>Register as an admin</h>
    </div>
    <form action="user_login.php" method="post">
  <div class="form-group">
  <form  action="user_login" method="POST">
  <div class="mb-3"> 
  <div class="mb-3">
    <label for="exampleInputUsername" class="form-label">Username</label>
    <input type="text"  name="username"class="form-control" id="exampleInputUsername">
  </div>
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password"  name="pwds"class="form-control" id="exampleInputPassword1">
  </div>

  <button type="submit" name="Submit" class="btn btn-primary">Register</button>
</form>
</div>


<?php
//Adding to database
if(isset($_POST['Submit'])){
    
    $usname = $_POST['username'];
    $email=$_POST['email'];
    $pwd = $_POST['pwds'];
    $hash = password_hash("$pwd", PASSWORD_BCRYPT);

    $query = "INSERT INTO `user` (`username`,`email`,`pwds`) VALUES ('$usname', '$hash')";
    $run = (mysqli_query($con,$query));
    if($run) {
       echo "<script>alert('User successfully registered:..');window.location.href='adminlist.php';</script>" ;
    }
    else{
         echo "something went wrong";
        }
    

}
?>
</body>
</Html>