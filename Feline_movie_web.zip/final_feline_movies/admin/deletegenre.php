<?php
include 'db.php';

$id=$_GET['id'];
$query="DELETE FROM `genre` WHERE id=$id";
$run = mysqli_query($con, $query);
if($run){
    echo "<script>alert('genre deleted'); window.location.href='genrelist.php';</script>";
}
else{
    echo "<script>alert('something went wrong'); wondow.location.href='genrelist.php'; </script>";
}

?>