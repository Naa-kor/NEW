<?php
include 'header.php';

include 'db.php';
?>

<div class="container">
    <div class= "head" style="text-align:center; padding-top:10px; padding-bottom:10px">
       <h2>Genre of Feline Movies</h2> 
    </div>
    <a class="btn btn-warning text-light" href="addgenre.php">Add Genre</a>
    <br>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Genre Name</th>
      <th scope="col">Category ID</th>
      <th scope="col">Genre ID</th>

    </tr>
  </thead>
  
 <?php
 $query = "SELECT * FROM genre";
 $run = mysqli_query($con, $query) ;
 if($run){
     while ($row = mysqli_fetch_assoc($run)){
       
?>
<tbody>
    <tr>
      <th scope="row"><?php echo $row['id'];?></th>
      <td><?php echo $row['genre_name'];?></td>
      <td><?php echo $row['category_id'];?></td>
      <td><?php echo $row['genreid'];?></td>
      <td>
          <a class="btn btn-danger" href="deletegenre.php?id=<?php echo $row['id'];?>">Delete</a> 
         </td>
    </tr>
    <?php
}
}

?>

  </tbody>
</table>
</div>

</div>


    