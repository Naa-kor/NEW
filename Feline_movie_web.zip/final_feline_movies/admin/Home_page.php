<?php 
include "header.php>";
include "db.php";
?>

<html>
<head>
</head>
<body>
<div class= "container">
<div class="row">
<?php
 $query = "SELECT * FROM movie";
 $run = mysqli_query($con, $query) ;
 if($run){
     while ($row = mysqli_fetch_assoc($run)){     
?>
<div class="col-md-3">
  <div class="card" style="width:250px;text-align:center">
  <?php echo"<img height='180' width='auto' src='../thumbs".$row['img']."'>";?>
    <div class="card-body">
      <h4 class="card-title"><?php echo $row['mv_name'];?></h4>
      <p class="card-text"><?php echo $row['meta_description'];?></p>
      <!--<a href="viewmovie.php?id=<?php echo $row['id'];?>" class="btn btn-secondary stretched-link"> View details</a>
      <br>
      <br>-->
      <a href="https://www.youtube.com/watch?v=Peh90SlJrzM" class="btn btn-info">Watch</a>
      
    </div>
  </div>
</div>
<?php
     }
    }
 ?>
 </div>
</div>


    
</body>

</html>