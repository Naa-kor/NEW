<?php
Include "header.php";
Include "db.php";
?>

<div class= "container">
    <div class= "head" style="text-align:center; padding-top:10px; padding-bottom:10px"> 
        <h1>Categories of Feline Movies</h1>
    </div>
    <a href="addcategory.php" class= "btn btn-warning text-light">Add a Category</a>
    <br>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Category ID <small>Foreign Key</small></th>
      <th scope="col">Category Name</th>
      <th scope="col">CRUD</th>

    </tr>
  </thead>
  
 <?php
 $query = "SELECT * FROM category";
 $run = mysqli_query($con, $query) ;
 if($run){
     while ($row = mysqli_fetch_assoc($run)){
?>
<tbody>
    <tr>
      <th scope="row"><?php echo $row['id'];?></th>
      <td><?php echo $row['category_id'];?></td>
      <td><?php echo $row['category_name'];?></td>
      <td><?php echo $row['post'];?></td>
      <td>
          <a class="btn btn-danger" href="deletecategory.php?deleteid=<?php echo $row['id'];?>">Delete</a> 
          <a class="btn btn-outline-secondary" href="editcategory.php?id=<?php echo $row['id']; ?>&forkey=<?php echo $row['category_id'];?> &catname=
          <?php echo $row['category_name']; ?>"
          >Edit</a></td>
    </tr>
    <?php
}
}

?>

  </tbody>
</table>
</div>