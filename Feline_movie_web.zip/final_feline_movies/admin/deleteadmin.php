<?php
include 'db.php';
include  'header.php';
$id= $_GET['id'];
$query="DELETE FROM `admin` WHERE id=$id";
$run = mysqli_query($con, $query);

if($run){
    echo "<script>alert('Admin deleted'); window.location.href='adminlist.php';</script>";
}
else{
    echo "<script>alert('something went wrong'); wondow.location.href='adminlist.php'; </script>";
}
?>