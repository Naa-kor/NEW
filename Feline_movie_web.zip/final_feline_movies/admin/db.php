<?php
require __DIR__ ."/db_cred.php";
//creating connection
$con = new mysqli(servername, username, password, dbname);

//checking connection
if($con->connect_error){
    die("connection failed:" .$con-> connect_error); 
    echo"connection failed";
}
else{
    echo "";
}