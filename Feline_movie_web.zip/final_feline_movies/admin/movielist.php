<?php
include 'header.php';
include 'db.php';
?>
<div class="overflow-auto">

<a class="btn btn-warning text-light" href="addmovie.php">Add Movie</a>
<div class="row">
<?php
 $query = "SELECT * FROM movie";
 $run = mysqli_query($con, $query) ;
 if($run){
     while ($row = mysqli_fetch_assoc($run)){     
?>
<div class="col-md-3">
  <div class="card" style="width:250px;text-align:center; display:flex">
  <p><?php echo $row['id'];?></p>
  <?php echo"<img height='180' width='auto' src='../thumbs".$row['img']."'>";?>
    <div class="card-body">
      <h4 class="card-title"><?php echo $row['mv_name'];?></h4>
      <p class="card-text"><?php echo $row['meta_description'];?></p>
      <!--<a href="viewmovie.php?id=<?php echo $row['id'];?>" class="btn btn-secondary stretched-link"> View details</a>
      <br>
      <br>-->
      <a href="deletemovie.php?id=<?php echo $row['id'];?>" class="btn btn-danger">Delete</a>
      <a href="editmovie.php?id=<?php echo $row['id'];?>" class="btn btn-info"> Edit</a>
    </div>
  </div>
</div>
<?php
     }
    }
 ?>
 </div>
 </div>

