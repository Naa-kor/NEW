<?php
include "db.php";
include "header.php";


if(isset($_GET['id'])){
    $id=$_GET['id'];
    $query="DELETE FROM `movie` WHERE id=$id";
    $run = mysqli_query($con, $query);
    if($run){
        header ('location:movielist.php');
    }
    else{
    echo "<script>alert('something went wrong'); wondow.location.href='movielist.ph'; </script>";
    }
}

else{
    header('location:movielist.php');
}

?>