<?php
include 'header.php';

include 'db.php';
?>

<?php
if(isset($_GET['id'])){
    $id= $_GET['id'];
    $gen = $_GET['genrename'];
    $catid= $_GET['catid'];
    if(isset($_POST['submit'])){
        $c=$_POST['categoryname'];
        $frky=$_POST['frky'];
        $pid=$_POST['pid'];

        $query= "UPDATE `genre` SET `id`='$pid',`category_id`='$frky',`category_name`='$cname' WHERE `id`='$id'";
        $run = mysqli_query($con,$query);
        if($run){
            echo "<script>alert('uptated'); window.location.href='categorylist.php';</script>";
        }
        else{
            echo "<script>alert('something went wrong'); window.location.href='editcategory.php';</script>";
        }
    }

}
else{
    header('location:categorylist.php');
}
?>


<div class= "container">
   <!<div class = "head">
        <div class="jumbotron">
  <h1 class="display-4">Edit Genre</h1>
  <p class="lead"> Edit Genre and also please mention the Category ID </p>
  <hr class="my-4">
  <form action="editgenre.php" method="post" >
  <div class="form-row">
    <div class="col-7">
      <input type="text" name="genrename" class="form-control" placeholder="Genre name">
    </div>
    <div class="col">
      <input type="text" name="cat_id" class="form-control" placeholder="Category Id">
    </div>
    <div class="col">
      <input type="text" name="genre_id" class="form-control" placeholder="Genre Id">
    </div>
  </div>
  <br></br>
  <button type="submit" name="submit" class="btn btn-primary">Edit Genre</button>
</form>
</div>
    </div>
</div>
