<?php
include "db.php";
$id=$_GET['deleteid'];
$query="DELETE FROM `admin` WHERE id=$id";
$run = mysqli_query($con, $query);
if($run){
    echo "<script>alert('category deleted'); window.location.href='adminlist.php';</script>";
}
else{
    echo "<script>alert('something went wrong'); wondow.location.href='categorylist.php'; </script>";
}

?>